# Tärnö Dyklogg – Android

Detta repo innehåller Tärnö Dykeris dyklogg som webbapp och bygger den till en Android-APK med Capacitor och GitHub Actions.

## Snabbaste vägen

1. Skapa ett nytt GitHub-repo, exempelvis `Tarno-Dyklogg`.
2. Ladda upp **innehållet** i denna ZIP till repots rot. `.github`-mappen måste följa med.
3. Öppna fliken **Actions** i GitHub.
4. Välj **Bygg Tärnö Dyklogg APK**.
5. Tryck **Run workflow** om bygget inte redan startat automatiskt.
6. När bygget är grönt: öppna körningen och ladda ner artifacten **Tarno_Dyklogg_APK**.
7. Packa upp den nedladdade artifact-ZIP:en. Där ligger `Tarno_Dyklogg.apk`.
8. Öppna APK-filen på Samsung och tillåt installation från den källa du använder om Android frågar.

## App-ID

`se.tarnodykeri.dyklogg`

## Viktigt

Detta bygger en debug-APK för direkt installation/test. För publicering i Google Play krävs senare en signerad release/AAB.
