# Tärnö Dyklogg

Android-app för dykledarjournal med live-timer, besättning, dyktider, historik och utskrift till PDF.

## Hämta APK

Öppna **Actions** → senaste gröna bygget → **Tarno_Dyklogg_APK**. Packa upp ZIP-filen och installera `app-debug.apk` på Android.

Appen lagrar uppgifter lokalt på telefonen och kräver ingen internetanslutning.
